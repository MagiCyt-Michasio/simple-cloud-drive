#!/usr/bin/env bash
set -Eeuo pipefail
cd /home/magic/C
exec node server.js
