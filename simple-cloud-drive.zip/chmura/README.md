# Simple Cloud Drive 1.1

## Aktualizacja z 1.0
Dodano nawigację po katalogach, ścieżkę breadcrumb oraz upload do aktualnie otwartego katalogu. Pobieranie, udostępnianie i usuwanie działają również dla plików/katalogów zagnieżdżonych.

## Start
```bash
npm install
cp .env.example .env
nano .env   # ustaw FILECLOUD_PASSWORD
./start.sh
```
Otwórz `http://IP:1212`. Użytkownik przy logowaniu Basic Auth może być dowolny; hasło pochodzi z `.env`.

Dane znajdują się w `./storage`. Nie wystawiaj serwera bezpośrednio do Internetu bez HTTPS/VPN. Linki udostępniania są dostępne każdemu, kto zna token.


## Publiczne linki bez hasła
Przycisk „Udostępnij link” tworzy losowy adres `/s/TOKEN`. Odbiorca pobiera plik bez logowania i hasła. Panel oraz API nadal wymagają hasła. Każdy, kto otrzyma link, może pobrać plik.
