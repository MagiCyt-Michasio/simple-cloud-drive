'use strict';
const express=require('express'), session=require('express-session'), helmet=require('helmet');
const multer=require('multer'), fs=require('fs'), path=require('path'), crypto=require('crypto');
const bcrypt=require('bcryptjs'), archiver=require('archiver');
require('dotenv').config?.();
const app=express(), PORT=Number(process.env.PORT||1212), ROOT=path.resolve(process.env.DATA_DIR||'./storage');
const FILES=path.join(ROOT,'files'), META=path.join(ROOT,'meta'), TMP=path.join(ROOT,'tmp');
for(const d of [FILES,META,TMP]) fs.mkdirSync(d,{recursive:true});
const sharesFile=path.join(META,'shares.json');
const readShares=()=>{try{return JSON.parse(fs.readFileSync(sharesFile,'utf8'))}catch{return {}}};
const writeShares=x=>fs.writeFileSync(sharesFile,JSON.stringify(x,null,2),{mode:0o600});
const clean=s=>String(s||'').replace(/\\/g,'/').split('/').filter(x=>x&&x!=='.'&&x!=='..').join('/');
function resolveSafe(rel=''){const r=path.resolve(FILES,clean(rel));if(r!==FILES&&!r.startsWith(FILES+path.sep))throw Error('Nieprawidłowa ścieżka');return r;}
function relOf(abs){return path.relative(FILES,abs).split(path.sep).join('/');}
function exists(p){try{return fs.statSync(p)}catch{return null}}
function list(rel=''){const dir=resolveSafe(rel);if(!exists(dir)?.isDirectory())throw Error('Folder nie istnieje');return fs.readdirSync(dir,{withFileTypes:true}).map(e=>{const p=path.join(dir,e.name),s=fs.statSync(p);return {name:e.name,path:relOf(p),type:e.isDirectory()?'folder':'file',size:s.size,modified:s.mtime.toISOString()}}).sort((a,b)=>a.type===b.type?a.name.localeCompare(b.name):a.type==='folder'?-1:1);}
app.disable('x-powered-by');app.use(helmet({contentSecurityPolicy:false}));app.use(express.json({limit:'2mb'}));
app.use(session({secret:process.env.SESSION_SECRET||crypto.randomBytes(32).toString('hex'),resave:false,saveUninitialized:false,cookie:{httpOnly:true,sameSite:'lax',secure:false,maxAge:7*86400000}}));
app.use(express.static(path.join(__dirname,'public')));
const authed=(req,res,next)=>req.session.ok?next():res.status(401).json({error:'Wymagane logowanie'});
app.post('/api/login',(req,res)=>{if(String(req.body.password||'')===String(process.env.ADMIN_PASSWORD||'')){req.session.ok=true;return res.json({ok:true});}res.status(403).json({error:'Nieprawidłowe hasło'});});
app.post('/api/logout',(req,res)=>req.session.destroy(()=>res.json({ok:true})));
app.get('/api/me',(req,res)=>res.json({logged:!!req.session.ok}));
app.get('/api/list',authed,(req,res)=>{try{const dir=clean(req.query.path);res.json({path:dir,items:list(dir)});}catch(e){res.status(400).json({error:e.message});}});
app.post('/api/folder',authed,(req,res)=>{try{const parent=resolveSafe(req.body.path||''),name=path.basename(String(req.body.name||'').trim());if(!name||name==='.'||name==='..')throw Error('Podaj nazwę folderu');fs.mkdirSync(path.join(parent,name));res.json({ok:true});}catch(e){res.status(400).json({error:e.message});}});
app.post('/api/rename',authed,(req,res)=>{try{const src=resolveSafe(req.body.path),name=path.basename(String(req.body.name||'').trim());if(!name)throw Error('Pusta nazwa');fs.renameSync(src,path.join(path.dirname(src),name));res.json({ok:true});}catch(e){res.status(400).json({error:e.message});}});
app.post('/api/move',authed,(req,res)=>{try{const src=resolveSafe(req.body.path),dstDir=resolveSafe(req.body.destination||'');if(!exists(src)||!exists(dstDir)?.isDirectory())throw Error('Nie znaleziono elementu docelowego');if(dstDir===src||dstDir.startsWith(src+path.sep))throw Error('Nie można przenieść folderu do samego siebie');const dst=path.join(dstDir,path.basename(src));if(exists(dst))throw Error('Element o tej nazwie już istnieje');fs.renameSync(src,dst);res.json({ok:true});}catch(e){res.status(400).json({error:e.message});}});
app.delete('/api/item',authed,(req,res)=>{try{const p=resolveSafe(req.body.path);if(p===FILES)throw Error('Nie można usunąć katalogu głównego');fs.rmSync(p,{recursive:true,force:false});res.json({ok:true});}catch(e){res.status(400).json({error:e.message});}});
const upload=multer({storage:multer.diskStorage({destination:(req,file,cb)=>{try{cb(null,resolveSafe(req.query.path||''))}catch(e){cb(e)}},filename:(req,file,cb)=>cb(null,path.basename(file.originalname).replace(/[\\/\0]/g,'_'))}),limits:{fileSize:20*1024*1024*1024,files:1000},fileFilter:(req,file,cb)=>cb(null,true)});
app.post('/api/upload',authed,(req,res)=>upload.array('files',1000)(req,res,e=>{if(e)return res.status(400).json({error:e.message});res.json({ok:true,count:req.files?.length||0});}));
function sendFile(res,p){if(!exists(p)?.isFile())return res.status(404).end('Nie znaleziono pliku');res.download(p,path.basename(p));}
app.get('/api/download',authed,(req,res)=>{try{sendFile(res,resolveSafe(req.query.path));}catch(e){res.status(400).end(e.message);}});
function addPathToZip(zip,abs,base){const st=fs.statSync(abs);if(st.isDirectory()){zip.directory(abs,base); }else zip.file(abs,{name:base||path.basename(abs)});}
app.post('/api/zip',authed,(req,res)=>{try{const paths=(req.body.paths||[]).map(resolveSafe);if(!paths.length)throw Error('Nic nie zaznaczono');const name=String(req.body.name||'pobieranie.zip').replace(/[^a-zA-Z0-9._-]/g,'_');res.attachment(name.endsWith('.zip')?name:name+'.zip');const zip=archiver('zip',{zlib:{level:5}});zip.on('error',e=>{if(!res.headersSent)res.status(500);res.end();});zip.pipe(res);for(const p of paths){if(!exists(p))continue;addPathToZip(zip,p,path.basename(p));}zip.finalize();}catch(e){res.status(400).json({error:e.message});}});
app.post('/api/share',authed,async(req,res)=>{try{const p=resolveSafe(req.body.path);if(!exists(p))throw Error('Nie znaleziono elementu');const token=crypto.randomBytes(24).toString('hex'),password=String(req.body.password||'');const shares=readShares();shares[token]={path:relOf(p),passwordHash:password?await bcrypt.hash(password,10):null,created:Date.now()};writeShares(shares);res.json({url:`${req.protocol}://${req.get('host')}/s/${token}`,protected:!!password});}catch(e){res.status(400).json({error:e.message});}});
app.get('/s/:token',(req,res)=>{const sh=readShares()[req.params.token];if(!sh)return res.status(404).send('Link nie istnieje');if(sh.passwordHash&&!req.session['share_'+req.params.token])return res.sendFile(path.join(__dirname,'public','share.html'));try{const p=resolveSafe(sh.path);if(exists(p)?.isFile())return sendFile(res,p);res.sendFile(path.join(__dirname,'public','share.html'));}catch(e){res.status(404).end('Nie znaleziono');}});
app.post('/api/share/:token/unlock',async(req,res)=>{const sh=readShares()[req.params.token];if(!sh)return res.status(404).json({error:'Link nie istnieje'});if(sh.passwordHash&&!await bcrypt.compare(String(req.body.password||''),sh.passwordHash))return res.status(403).json({error:'Nieprawidłowe hasło'});req.session['share_'+req.params.token]=true;res.json({ok:true});});
app.get('/api/share/:token/list',(req,res)=>{const sh=readShares()[req.params.token];if(!sh)return res.status(404).json({error:'Link nie istnieje'});if(sh.passwordHash&&!req.session['share_'+req.params.token])return res.status(401).json({error:'Hasło wymagane'});try{const p=resolveSafe(sh.path);if(exists(p)?.isDirectory())return res.json({items:list(sh.path)});res.json({file:path.basename(p),url:'/api/share/'+req.params.token+'/download'});}catch(e){res.status(404).json({error:e.message});}});
app.get('/api/share/:token/download',(req,res)=>{const sh=readShares()[req.params.token];if(!sh)return res.status(404).end();if(sh.passwordHash&&!req.session['share_'+req.params.token])return res.status(401).end('Hasło wymagane');try{sendFile(res,resolveSafe(sh.path));}catch(e){res.status(404).end(e.message);}});
app.get('/api/share/:token/zip',(req,res)=>{const sh=readShares()[req.params.token];if(!sh)return res.status(404).end();if(sh.passwordHash&&!req.session['share_'+req.params.token])return res.status(401).end('Hasło wymagane');try{const p=resolveSafe(sh.path);res.attachment(path.basename(p)+'.zip');const z=archiver('zip',{zlib:{level:5}});z.on('error',()=>res.end());z.pipe(res);addPathToZip(z,p,path.basename(p));z.finalize();}catch(e){res.status(404).end(e.message);}});

// Bezpieczny podgląd plików w panelu (tylko zalogowany użytkownik).
app.get('/api/preview',authed,(req,res)=>{
  try {
    const p=resolveSafe(req.query.path);
    const st=exists(p);
    if(!st || !st.isFile()) return res.status(404).end('Nie znaleziono pliku');
    const ext=path.extname(p).toLowerCase();
    const types={
      '.jpg':'image/jpeg','.jpeg':'image/jpeg','.png':'image/png','.gif':'image/gif',
      '.webp':'image/webp','.svg':'image/svg+xml','.avif':'image/avif',
      '.pdf':'application/pdf','.txt':'text/plain; charset=utf-8','.md':'text/plain; charset=utf-8',
      '.log':'text/plain; charset=utf-8','.json':'application/json; charset=utf-8',
      '.csv':'text/csv; charset=utf-8','.mp4':'video/mp4','.webm':'video/webm',
      '.mov':'video/quicktime','.mp3':'audio/mpeg','.wav':'audio/wav','.ogg':'audio/ogg'
    };
    const type=types[ext];
    if(!type) return res.status(415).json({error:'Podgląd tego typu pliku nie jest obsługiwany'});
    res.setHeader('Content-Type',type);
    res.setHeader('Content-Disposition','inline; filename="'+path.basename(p).replace(/["\\r\\n]/g,'_')+'"');
    res.setHeader('X-Content-Type-Options','nosniff');
    res.setHeader('Cache-Control','private, no-store');
    res.setHeader('Content-Length',st.size);
    fs.createReadStream(p).pipe(res);
  } catch(e) { res.status(400).end(e.message); }
});

app.listen(PORT,'0.0.0.0',()=>console.log(`Simple Cloud Drive 3.0: http://0.0.0.0:${PORT}`));
